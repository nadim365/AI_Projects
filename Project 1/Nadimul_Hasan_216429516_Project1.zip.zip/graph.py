from collections import defaultdict
from typing import Dict

class   Graph:

    def     __init__(self) :
        self.graph = defaultdict(list)
        self.heuristic = dict()

    def addEdge(self, u, v):
        self.graph[u].append(v)

    def build(self, input): 

        file = open(input)
        for x in file: 
            x.strip("\n")
            if x != "END" : 
                node = x.split(" ")
                self.addEdge(node[0], [ node[1], int(node[2]) ] )
                self.addEdge(node[1], [ node[0], int(node[2]) ] )
        file.close()
    
    def successor(self, parent) : 
        children = list()
        for x in self.graph : 
            if x == parent :
                children = self.graph[x]
    
        return children

    def heuristic_func(self, input) : 
        file = open(input)

        for x in file:
            x = x.strip("\n")
            if ( x != "END" ) and (x != "") :
                node = x.split(" ")
                loc = node[0]
                h = int(node[-1])
                self.heuristic.update({loc: h})
        
        file.close()



###
# g = Graph()
#g.build("input_file1.txt")
#a = g.successor("Toledo")
#print(a)
###
